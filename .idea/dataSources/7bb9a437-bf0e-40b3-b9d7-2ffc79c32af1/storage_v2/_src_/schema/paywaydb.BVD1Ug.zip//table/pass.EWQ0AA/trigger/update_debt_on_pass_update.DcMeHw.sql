create definer = root@localhost trigger update_debt_on_pass_update
    after update
    on pass
    for each row
BEGIN
    DECLARE old_home_op_id VARCHAR(5);
    DECLARE old_station_op_id VARCHAR(5);
    DECLARE new_home_op_id VARCHAR(5);
    DECLARE new_station_op_id VARCHAR(5);

    -- Get the home operator ID of the tag (OLD values)
    SELECT op_id INTO old_home_op_id
    FROM Tag
    WHERE tag_ref = OLD.tag_ref;

    -- Get the operator ID of the toll station (OLD values)
    SELECT op_id INTO old_station_op_id
    FROM TollStation
    WHERE station_id = OLD.station_id;

    -- Get the home operator ID of the tag (NEW values)
    SELECT op_id INTO new_home_op_id
    FROM Tag
    WHERE tag_ref = NEW.tag_ref;

    -- Get the operator ID of the toll station (NEW values)
    SELECT op_id INTO new_station_op_id
    FROM TollStation
    WHERE station_id = NEW.station_id;

    -- Adjust the Debt table for OLD values if the operators were different
    IF old_home_op_id != old_station_op_id THEN
    UPDATE Debt
    SET debt_amount = debt_amount - OLD.charge,
        last_update = CURRENT_TIMESTAMP
    WHERE from_op_id = old_home_op_id AND to_op_id = old_station_op_id;

    -- Remove the debt row if the debt amount reaches zero
    DELETE FROM Debt
    WHERE from_op_id = old_home_op_id AND to_op_id = old_station_op_id AND debt_amount <= 0;
END IF;

-- Adjust the Debt table for NEW values if the operators are different
IF new_home_op_id != new_station_op_id THEN
        INSERT INTO Debt (from_op_id, to_op_id, debt_amount, last_update)
        VALUES (new_home_op_id, new_station_op_id, NEW.charge, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE
                                debt_amount = debt_amount + NEW.charge,
                                last_update = CURRENT_TIMESTAMP;
END IF;
END;

