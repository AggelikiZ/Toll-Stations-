create definer = root@localhost trigger update_debt_on_pass_delete
    after delete
    on pass
    for each row
BEGIN
    DECLARE home_op_id VARCHAR(5);
    DECLARE station_op_id VARCHAR(5);

    -- Get the home operator ID of the tag
    SELECT op_id INTO home_op_id
    FROM Tag
    WHERE tag_ref = OLD.tag_ref;

    -- Get the operator ID of the toll station
    SELECT op_id INTO station_op_id
    FROM TollStation
    WHERE station_id = OLD.station_id;

    -- Check if they are different operators
    IF home_op_id != station_op_id THEN
        -- Update the Debt table
    UPDATE Debt
    SET debt_amount = debt_amount - OLD.charge,
        last_update = CURRENT_TIMESTAMP
    WHERE from_op_id = home_op_id AND to_op_id = station_op_id;

    -- Remove the debt row if the debt amount reaches zero
    DELETE FROM Debt
    WHERE from_op_id = home_op_id AND to_op_id = station_op_id AND debt_amount <= 0;
END IF;
END;

