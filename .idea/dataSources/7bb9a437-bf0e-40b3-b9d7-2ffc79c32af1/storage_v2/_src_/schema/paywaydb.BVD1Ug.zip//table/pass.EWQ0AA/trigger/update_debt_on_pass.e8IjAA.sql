create definer = root@localhost trigger update_debt_on_pass
    after insert
    on pass
    for each row
BEGIN
    DECLARE home_op_id VARCHAR(5);
    DECLARE station_op_id VARCHAR(5);

    -- Get the home operator ID of the tag
    SELECT op_id INTO home_op_id
    FROM Tag
    WHERE tag_ref = NEW.tag_ref;

    -- Get the operator ID of the toll station
    SELECT op_id INTO station_op_id
    FROM TollStation
    WHERE station_id = NEW.station_id;

    -- Check if they are different operators
    IF home_op_id != station_op_id THEN
        -- Update the Debt table
        INSERT INTO Debt (from_op_id, to_op_id, debt_amount, last_update)
        VALUES (home_op_id, station_op_id, NEW.charge, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE
                                    debt_amount = debt_amount + NEW.charge,
                                    last_update = CURRENT_TIMESTAMP;
END IF;
END;

