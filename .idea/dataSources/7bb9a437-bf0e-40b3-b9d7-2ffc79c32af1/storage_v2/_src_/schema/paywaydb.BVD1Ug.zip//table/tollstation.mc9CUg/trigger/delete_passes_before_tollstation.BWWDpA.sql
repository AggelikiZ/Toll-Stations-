create definer = root@localhost trigger delete_passes_before_tollstation
    before delete
    on tollstation
    for each row
BEGIN
    -- Delete all passes associated with the station being deleted
    DELETE FROM pass
    WHERE station_id = OLD.station_id;
END;

